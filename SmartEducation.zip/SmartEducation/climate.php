<html lang="es">
<head>
  <!-- FAVICON-->
<link rel="icon" type="image/png" href="i3.png" sizes="16x16">


<style>


body {
  font-size: 28px;
}

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
  position: -webkit-sticky; /* Safari */
  position: sticky;
  top: 0;
}
li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color: #CC2EFA;
}
.active {
  background-color: #CC2EFA;
}
div {
  padding: 70px;
  border: 1px solid #CC2EFA;
  font-size: 36px;
  background-color: #E6E6E6;
color: #8904B1;
font-family: 'Open Sans';
}
</style>





<marquee bgcolor="BLACK" behavior="scroll" direction="left">

<b><font face="MV Boli" color="6633FF" size="7">Smart Education</font></b>
</marquee>


<ul>
  <li><a  href="index.php">Home</a></li>

  <li><a href="video.php">Videos</a></li>
  
  <li><a class="active"href="lecciones.php">Lecciones</a></li>
  <li><a href="cuentos.php">Cuentos</a></li>
  <li><a href="contacto.php">Sobre nosotros</a></li>
</ul>




<!-- https://www.curso-ingles.com/-->

<!-- TITULO PAGINA -->
<title> Smart Education </title>
</head>
<body>
<a href="lecciones.php">Regresar</a>
<center>

<h1><B> 3.1 Climate  </B><br></h1>
<div>
En esta clase miramos los principales verbos, adjetivos y sustantivos relacionados con el tiempo en inglés.  

</div>
</center>


<div2>
	
  <h3><br>Miramos los sustantivos que usamos en inglés para describir el tiempo:<br></h3><img align="left" src="cli.png">

<br><audio src="c1.mp3" preload="none" controls></audio> <br>


<b><br>Algunos ejemplos<br><br></b>

Ejemplos:<br>
<li>I hate the rain! - ¡Odio la lluvia!</li><br>
<li>We always have snow in November - Siempre tenemos nieve en noviembre</li><br>
<li>There's a storm coming - Viene una tormenta</li><br><img align="left" src="ll.gif">
<li>The sun is behind the clouds* - El sol está detrás de los nubes</li><br>
<li>The wind is very strong today - El viento es muy fuerte hoy</li><br>
<br><audio src="c2.mp3" preload="none" controls></audio> <br><br>
<b>*Algo muy habitual en el Reino Unido por desgracia.</b>
<br><br>

</div2><img align="right" src="clim.png">

</html>