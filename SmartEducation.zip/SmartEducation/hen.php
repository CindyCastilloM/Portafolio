<html lang="es">
<head>
  <!-- FAVICON-->
<link rel="icon" type="image/png" href="i3.png" sizes="16x16">


<style>


body {
  font-size: 28px;
}

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
  position: -webkit-sticky; /* Safari */
  position: sticky;
  top: 0;
}
li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color: #CC2EFA;
}
.active {
  background-color: #CC2EFA;
}

</style>
</head>


<!-- TITULO PAGINA -->
<title> Smart Education </title>


<marquee bgcolor="BLACK" behavior="scroll" direction="left">

<b><font face="MV Boli" color="6633FF" size="7">Smart Education</font></b>
</marquee>


<ul>
  <li><a  href="index.php">Home</a></li>

  <li><a href="video.php">Videos</a></li>
  
  <li><a href="lecciones.php">Lecciones</a></li>
  <li><a class="active"href="cuentos.php">Cuentos</a></li>
  <li><a href="contacto.php">Sobre nosotros</a></li>
</ul>

<center>
  <h2><font face="Calibri" size="8" color="black">Little Red Hen<br></font>
    <font face="Calibri" size="5" > Anonymous<br>
      <br><audio src="Little_red_hen.mp3" preload="none" controls></audio><br><br>

      <img width="700" align="right" src="h1.png">
<div>
<font face="Calibri" size="6" >
  Once upon a time there was a red hen that found a grain of wheat.<br><br>

“Who will plant this grain?” she asked.<br><br>

“Not me,” said the dog.<br><br>

“Not me,” said the cat.<br><br>

“Not me,” said the pig.<br><br>

“Not me,” said the mouse.<br><br>

“Then I will,” said the little red hen. Cluck, cluck!<br><br>

She planted the grain of wheat and it grew very tall.<br><br>

“Who will cut this wheat?” asked the little red hen<br><br>

“Not me,” said the dog.<br><br>

“Not me,” said the cat.<br><br>

“Not me,” said the pig.<br><br>

“Not me,” said the mouse.<br><br>

“Then I will,” said the little red hen. Cluck, cluck!<br><br>

The little red hen cut the wheat.<br><br>

“Who will take the wheat to the mill to make the flour?” asked the little red hen.<br><br>

“Not me,” said the dog.<br><br>

“Not me,” said the cat.<br><br>

“Not me,” said the pig.<br><br>

“Not me,” said the mouse.<br><br>

“Then I will,” said the little red hen. Cluck, cluck!<br><br>

She took the wheat to the mill and later returned with the flour.<br><br>

“Who will knead this flour?” asked the little red hen.<br><br>

“Not me,” said the dog.<br><br>

“Not me,” said the cat.<br><br>

“Not me,” said the pig.<br><br>

“Not me,” said the mouse.<br><br>

“Then I will,” said the little red hen. Cluck, cluck!<br><br>

The hen kneaded the flour and then baked the bread.<br><br>

“Who will eat this bread” asked the little red hen.<br><br>

“I will,” said the dog.<br><br>

“I will,” said the cat.<br><br>

“I will,” said the pig.<br><br>

“I will,” said the mouse.<br><br>

“No,” said the little red hen. “I will eat it myself!” Cluck, cluck!<br><br>

And she ate all the bread.<br><br>

<h3>Moral: Do not expect any reward without doing any of the work.</h3><br><br>

<img width="500" align="center" src="h2.png"><br>

<a href="cuentos.php">Regresar</a>
</div>